<div class="clearfix"></div>
<?= '</div></div></div></div></div>'; ?>
<div class="clearfix"></div>
<footer>
    <a href="#" id="toTop" class="blue" style="position: fixed; bottom: 30px; right: 30px; font-size: 30px; display: none;">
        <i class="fa fa-chevron-circle-up"></i>
    </a>

    <p style="text-align:center;color:#5BC0DE;">&copy; <?= date('Y') . " " . $Settings->site_name; ?> (v<?= $Settings->version; ?>
        ) <?php
        if ($_SERVER["REMOTE_ADDR"] == '127.0.0.1') {
            echo ' - Page rendered in <strong>{elapsed_time}</strong> seconds';
        }
        ?></p>
</footer>
<?= '</div>'; ?>
<div class="modal fade in" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>
<div class="modal fade in" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true"></div>
<div id="modal-loading" style="display: none;">
    <div class="blackbg"></div>
    <div class="loader"></div>
</div>
<div id="ajaxCall"><i class="fa fa-spinner fa-pulse"></i></div>
    <?php unset($Settings->setting_id, $Settings->smtp_user, $Settings->smtp_pass, $Settings->smtp_port, $Settings->update, $Settings->reg_ver, $Settings->allow_reg, $Settings->default_email, $Settings->mmode, $Settings->timezone, $Settings->restrict_calendar, $Settings->restrict_user, $Settings->auto_reg, $Settings->reg_notification, $Settings->protocol, $Settings->mailpath, $Settings->smtp_crypto, $Settings->corn, $Settings->customer_group, $Settings->envato_username, $Settings->purchase_code); ?>
<script type="text/javascript">
    var dt_lang = <?= $dt_lang ?>, dp_lang = <?= $dp_lang ?>, site = <?= json_encode(array('base_url' => base_url(), 'settings' => $Settings, 'dateFormats' => $dateFormats)) ?>;
    var lang = {paid: '<?= lang('paid'); ?>', pending: '<?= lang('pending'); ?>', completed: '<?= lang('completed'); ?>', ordered: '<?= lang('ordered'); ?>', received: '<?= lang('received'); ?>', partial: '<?= lang('partial'); ?>', sent: '<?= lang('sent'); ?>', r_u_sure: '<?= lang('r_u_sure'); ?>', due: '<?= lang('due'); ?>', returned: '<?= lang('returned'); ?>', transferring: '<?= lang('transferring'); ?>', active: '<?= lang('active'); ?>', inactive: '<?= lang('inactive'); ?>', unexpected_value: '<?= lang('unexpected_value'); ?>', select_above: '<?= lang('select_above'); ?>'};
</script>
<?php
$s2_lang_file = read_file('./assets/config_dumps/s2_lang.js');
foreach (lang('select2_lang') as $s2_key => $s2_line) {
    $s2_data[$s2_key] = str_replace(array('{', '}'), array('"+', '+"'), $s2_line);
}
$s2_file_date = $this->parser->parse_string($s2_lang_file, $s2_data, true);
?>
<script type="text/javascript" src="<?= $assets ?>js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/jquery.dataTables.dtFilter.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/select2.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/bootstrapValidator.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/custom.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/jquery.calculator.min.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/core.js"></script>
<script type="text/javascript" src="<?= $assets ?>js/perfect-scrollbar.min.js"></script>
<?= ($m == 'purchases' && ($v == 'add' || $v == 'edit' || $v == 'purchase_by_csv')) ? '<script type="text/javascript" src="' . $assets . 'js/purchases.js"></script>' : ''; ?>
<?= ($m == 'transfers' && ($v == 'add' || $v == 'edit')) ? '<script type="text/javascript" src="' . $assets . 'js/transfers.js"></script>' : ''; ?>
<?= ($m == 'sales' && ($v == 'add' || $v == 'edit')) ? '<script type="text/javascript" src="' . $assets . 'js/sales.js"></script>' : ''; ?>
<?= ($m == 'quotes' && ($v == 'add' || $v == 'edit')) ? '<script type="text/javascript" src="' . $assets . 'js/quotes.js"></script>' : ''; ?>
<?= ($m == 'products' && ($v == 'add' || $v == 'edit')) ? '<script type="text/javascript" src="' . $assets . 'js/productsChallan.js"></script>' : ''; ?>

<script type="text/javascript" charset="UTF-8">var r_u_sure = "<?= lang('r_u_sure') ?>";
<?= $s2_file_date ?>
    $.extend(true, $.fn.dataTable.defaults, {"oLanguage":<?= $dt_lang ?>});
    $.fn.datetimepicker.dates['sma'] = <?= $dp_lang ?>;
    $(window).load(function () {
        $('.mm_<?= $m ?>').addClass('active');
        $('.mm_<?= $m ?>').find("ul").first().slideToggle();
        $('#<?= $m ?>_<?= $v ?>').addClass('active');
        $('.mm_<?= $m ?> a .chevron').removeClass("closed").addClass("opened");
    });
</script>
<script type="text/javascript">var site_url = "<?= site_url() ?>";</script>
<script type="text/javascript" src="<?= $assets ?>bower_components/angular/angular.js"></script>
<script type="text/javascript" src="<?= $assets ?>bower_components/angular-ui-select2/src/select2.js"></script>
<script src="<?= $assets ?>js/angular.control.js" type="text/javascript"></script>
<script src="<?= $assets ?>js/services.js" type="text/javascript"></script>
<script>
    $('#addproduct').bootstrapValidator({
        feedbackIcons: {
            valid: 'fa fa-check',
            invalid: 'fa fa-times',
            validating: 'fa fa-refresh'
        },
        fields: {
            product_image: {
                validators: {
                    file: {
                        extension: 'jpeg,png',
                        type: 'image/jpeg,image/png',
                        maxSize: 1000,
                        maxSize: <?= (int) $this->Settings->iwidth ?> *<?= (int) $this->Settings->iheight ?>,
                                message: 'Please check image size. it has to be <?= byte_format($this->Settings->iwidth * $this->Settings->iheight) ?> Image size.'
                    }
                }
            },
            'userfile[]': {
                validators: {
                    file: {
                        extension: 'jpeg,png',
                        type: 'image/jpeg,image/png',
                        maxSize: 1000,
                        maxSize: <?= (int) $this->Settings->iwidth ?> *<?= (int) $this->Settings->iheight ?>,
                                message: 'Please check image size. it has to be <?= byte_format($this->Settings->iwidth * $this->Settings->iheight) ?> Image size.'
                    }
                }
            },
        }
    });
</script>
</body>
</html>
