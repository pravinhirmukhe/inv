<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * última edición: 22/03/2015
 * Ricardo Ramírez R.
 */

$lang['add_biller']        = "Añadir Facturador";
$lang['edit_biller']       = "Editar Facturador";
$lang['delete_biller']     = "Eliminar Facturador";
$lang['delete_billers']    = "Eliminar Facturadores";
$lang['biller_added']      = "Facturador añadido correctamente";
$lang['biller_updated']    = "Facturador actualizado correctamente";
$lang['biller_deleted']    = "Facturador eliminado correctamente";
$lang['billers_deleted']   = "Facturadores eliminados correctamente";
$lang['no_biller_selected']= "No hay facturador seleccionado. Por favor seleccione al menos un Facturador.";
$lang['invoice_footer']    = "Pie de página de factura";
$lang['biller_x_deleted_have_sales'] = "Action failed! biller have sales";
$lang['billers_x_deleted_have_sales'] = "Some billers cannot be deleted as they have sales";